import MenuAdd from './MenuAdd';

export default MenuAdd;
