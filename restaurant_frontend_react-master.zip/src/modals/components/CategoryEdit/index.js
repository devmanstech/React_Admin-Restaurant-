import CategoryEdit from './CategoryEdit';

export default CategoryEdit;
