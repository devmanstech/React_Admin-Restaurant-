import QRCode from './QRCode';

export default QRCode;