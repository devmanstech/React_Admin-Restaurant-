import RestaurantEdit from './RestaurantEdit';

export default RestaurantEdit;
