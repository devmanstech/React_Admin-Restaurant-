import CategoryAdd from './CategoryAdd';

export default CategoryAdd;
