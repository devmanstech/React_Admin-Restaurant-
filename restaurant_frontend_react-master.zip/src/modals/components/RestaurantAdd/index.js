import RestaurantAdd from './RestaurantAdd';

export default RestaurantAdd;
