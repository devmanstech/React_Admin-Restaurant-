import Cities from './Cities';

export default Cities;