import RestaurantTable from './RestaurantTable';

export default RestaurantTable;