import Restaurants from './Restaurants';

export default Restaurants;