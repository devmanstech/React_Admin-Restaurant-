import Edit from './Edit';

export default Edit;