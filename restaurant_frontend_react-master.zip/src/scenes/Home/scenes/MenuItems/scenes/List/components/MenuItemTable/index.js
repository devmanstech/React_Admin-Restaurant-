import MenuItemTable from './MenuItemTable';

export default MenuItemTable;
