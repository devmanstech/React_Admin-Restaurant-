import MenuTable from './MenuTable';

export default MenuTable;