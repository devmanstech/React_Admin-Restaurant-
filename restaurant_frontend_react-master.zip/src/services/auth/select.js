const getCurrentUser = state => state.default.services.auth;

export {
  getCurrentUser
}