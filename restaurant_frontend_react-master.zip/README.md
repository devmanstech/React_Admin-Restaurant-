--install

```
  npm install
  npm run start
```